package com.capg.Ewallet.DAO;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capg.Ewallet.Beans.Customer;
import com.capg.Ewallet.Exception.RecordNotFoundException;



@Repository
public class EWalletImpl implements IEwalletDAO 
{
	@PersistenceContext
	EntityManager manager;

	@Override
	public String login(String email, String pwd) throws RecordNotFoundException {
		
		TypedQuery<Customer> login = manager.createNamedQuery("validate",Customer.class);
		
		login.setParameter("email",email);
		login.setParameter("password", pwd);
		Customer customer = login.getSingleResult();
		if(customer==null)
		
			
		throw new RecordNotFoundException("Email or Password is Invalid ");
		
		else
		{
			return String.valueOf(customer.getC_id());
			//return "Incorrect";
		}
		
		
	}

	@Override
	public Customer registration(Customer customer) {
		
		 manager.persist(customer);
		 System.out.println("DAO "+customer);
		 return customer;
		
	}

	@Override
	public Double checkBalance(int cid) throws RecordNotFoundException {
		
		TypedQuery<Double> checkBalance = manager.createNamedQuery("checkBalance",Double.class);
		if(checkBalance==null)
		{
			throw new RecordNotFoundException("Invalid Account Number");
		}
		
		else
		{
			checkBalance.setParameter("c_id", cid);
			double cust_balance = checkBalance.getSingleResult();
			
			return cust_balance;
			
		}
	}

	@Override
	public Double depositAmount(int cid,double amount) {
		
		
		Customer customer = manager.find(Customer.class, cid);
		if(customer == null)
		{
			throw new RecordNotFoundException("Invalid Account Number");
		}
		
		else if(amount <= 0)
		{
			throw new RecordNotFoundException("Enter more than 0 amount.");
		}
		else if(amount > 1000000)
		{
			throw new RecordNotFoundException("Entered amount is more than 1000000.");
		}
	
		else
		
		{
			double d_amount = customer.getBalance();
			d_amount = d_amount + amount;
			customer.setBalance(d_amount);
			manager.merge(customer);
			return d_amount;
		}
		
	
		
		
		
	}

	@Override
	public Double withdrawAmount(int cid, double amount) throws RecordNotFoundException {
		
		Customer customer = manager.find(Customer.class, cid);
		
		if(customer == null)
		{
			throw new RecordNotFoundException("Invalid Account Number");
		}
		else if(amount <= 0)
		{
			throw new RecordNotFoundException("Enter more than 0 amount.");
		}
		else if(customer.getBalance() < amount)
		{
			throw new RecordNotFoundException("Insufficient Amount!!.");
		}
		else
		{
			double w_amount = customer.getBalance();
			w_amount = w_amount - amount;
			customer.setBalance(w_amount);
			manager.merge(customer);
			return w_amount;
			
		}
	}

	@Override
	public Double fundTransfer(int cid, int rid, double amount) throws RecordNotFoundException {
		
		Customer cust_id = manager.find(Customer.class,cid);
		Customer receiver_id = manager.find(Customer.class,rid);
	
		
		if(cust_id==null && receiver_id==null || cust_id==null && receiver_id!=null || cust_id!=null && receiver_id==null ||cust_id!=null && receiver_id!=null)
		{
			throw new RecordNotFoundException("Invalid Account Number.");
		}
		
		else if(cust_id.getBalance() < amount)
		{
			throw new RecordNotFoundException("Insufficient Amount!!");
		}
		else if(amount <= 0)
		{
			throw new RecordNotFoundException("Enter more than 0 amount.");
		}
		
		else
		{
			double c_f_bal = cust_id.getBalance();
			double r_f_bal = receiver_id.getBalance();
			 c_f_bal = cust_id.getBalance();
			 r_f_bal = receiver_id.getBalance();
			
			
			r_f_bal = r_f_bal + amount;
			c_f_bal = c_f_bal - amount;
			
			receiver_id.setBalance(r_f_bal);
			cust_id.setBalance(c_f_bal);
			
			manager.merge(cust_id);
			manager.merge(receiver_id);
			System.out.println("customer amount after transfer "+c_f_bal);
			System.out.println("Receiver amount after transfer "+r_f_bal);
			return c_f_bal;
		}
	}

	@Override
	public List<Customer> getAllCustomer() {
		
		TypedQuery<Customer> t = manager.createQuery("select customers from Customer customers",Customer.class);
		
		List<Customer> list = t.getResultList();
		
		
		return list;
	}

	@Override
	public Customer getSingleCustomerInfo(int cid) throws RecordNotFoundException {
		
		Customer cust = manager.find(Customer.class, cid);
		return cust;
	}

	@Override
	public Customer updateCustomer( Customer customer) throws RecordNotFoundException {
		
	
		
			return manager.merge(customer);
			
		
	
	}

//	@Override
//	public Customer getSingleCustomerInfo(String email ) throws RecordNotFoundException {
//		TypedQuery<Customer> get = manager.createQuery("select customer from Customer customer where email=:email",Customer.class);
//		get.setParameter("email",email);
//		Customer customer = get.getSingleResult(); 
//		return customer;
//	}
}
