package com.capg.Ewallet.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.capg.Ewallet.Beans.Customer;
import com.capg.Ewallet.Exception.RecordNotFoundException;
import com.capg.Ewallet.Service.IEwalletService;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class EWalletController 
{
	@Autowired
	IEwalletService service;
	
	@PostMapping(value="/login")
	public String login(@RequestBody Customer customer) throws RecordNotFoundException
	{
		System.out.println("email "+customer.getEmail());
		System.out.println("password "+customer.getPassword());
		
		System.out.println(service.login(customer.getEmail(), customer.getPassword()));
		return service.login(customer.getEmail(), customer.getPassword());
	}

	
	@PostMapping(value="/Signup")
	public Customer registration(@RequestBody Customer customer) throws RecordNotFoundException
	{
		System.out.println(customer);
		 return service.registration(customer);
 
	}
	
	@GetMapping(value="/checkBalance/{cid}")
	public Double checkBalance(@PathVariable int cid) throws RecordNotFoundException
	{
		System.out.println(cid);
		return service.checkBalance(cid);
		
	}
	
	@PutMapping(value="/depositeAmount/{cid}/{amount}")
	public Double depositAmount(@PathVariable int cid,@PathVariable double amount)
	{
		System.out.println(cid +" "+amount);
		return service.depositAmount(cid, amount);
	}
	
	@PutMapping(value="/withdrawAmount/{cid}/{amount}")
	public Double withdrawAmount(@PathVariable int cid,@PathVariable double amount) throws RecordNotFoundException 
	{
		System.out.println(cid +" "+amount);
		return service.withdrawAmount(cid, amount);
	}
	
	@PutMapping(value="/transferAmount/{cid}/{rid}/{amount}")
	public Double fundTransfer(@PathVariable int cid,@PathVariable int rid, @PathVariable double amount) throws RecordNotFoundException
	{
		System.out.println(cid);
		System.out.println(rid);
		System.out.println(amount);
		
		return service.fundTransfer(cid, rid, amount);
	}
	
	@GetMapping(value="/getAllCustomer")
	public List<Customer> getAllCustomer() throws RecordNotFoundException 
	{
		return service.getAllCustomer();
	}
	
	@GetMapping(value = "/getSingleCustomer/{cid}")
	public Customer getSingleCustomerInfo(@PathVariable int cid)
	{
		return service.getSingleCustomerInfo(cid);
	}
	
	@PutMapping(value = "/updateCustomer")
	public Customer updateCustomer(@RequestBody Customer customer)
	{
		return service.updateCustomer(customer);
				
	}
	
	
	
	//Exception handling for id
		@ResponseStatus(value=HttpStatus.NOT_FOUND,
				reason="Customer Not Found")
		@ExceptionHandler({RecordNotFoundException.class})
		public void handleException()
		{
			
		}
	
	
}
