package com.capg.Ewallet.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capg.Ewallet.Beans.Customer;
import com.capg.Ewallet.DAO.IEwalletDAO;
import com.capg.Ewallet.Exception.RecordNotFoundException;

@Service
@Transactional
public class EWalletServiceImpl implements IEwalletService 
{
	@Autowired
	IEwalletDAO dao;

	@Override
	public String login(String email, String pwd) throws RecordNotFoundException {
		
		return dao.login(email, pwd);
	}

	@Override
	public Customer registration(Customer customer) throws RecordNotFoundException {
		System.out.println("Service "+customer);
		return dao.registration(customer);
	}

	@Override
	public Double checkBalance(int cid) throws RecordNotFoundException {
		System.out.println("service "+cid);
		return dao.checkBalance(cid);
	}

	@Override
	public Double depositAmount(int cid,double amount) {
		
		System.out.println("service "+cid);
		
		return dao.depositAmount(cid,amount);
	}

	@Override
	public Double withdrawAmount(int cid, double amount) throws RecordNotFoundException {
	
		return dao.withdrawAmount(cid, amount);
	}

	@Override
	public Double fundTransfer(int cid, int rid, double amount) throws RecordNotFoundException {
		
		return dao.fundTransfer(cid, rid, amount);
	}

	@Override
	public List<Customer> getAllCustomer() throws RecordNotFoundException {
		
		return dao.getAllCustomer();
	}

	@Override
	public Customer getSingleCustomerInfo(int cid) throws RecordNotFoundException {
		
		
		return dao.getSingleCustomerInfo(cid);
	}

	@Override
	public Customer updateCustomer( Customer customer) throws RecordNotFoundException {
		
		return dao.updateCustomer( customer);
	}
}
