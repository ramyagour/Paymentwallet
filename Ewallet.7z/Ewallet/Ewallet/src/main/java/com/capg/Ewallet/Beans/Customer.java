package com.capg.Ewallet.Beans;




import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonFormat;


import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name="customer")
@Getter
@Setter
@NamedQueries({
		 
@NamedQuery(name = "validate",
query = "select customer from Customer customer where customer.email=:email and customer.password=:password"),
	
		
@NamedQuery(name = "checkBalance",
query="select customer.balance from Customer customer where customer.c_id=:c_id")

				
		})
		

public class Customer 
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int c_id;
	@Column(length = 5,columnDefinition = "varchar2(255)")
	private String fname;
	@Column(length = 5,columnDefinition = "varchar2(255)")
	private String lname;
	@JsonFormat(pattern="yyyy-MM-dd")
	private Date dob;
	@Column(length = 5)
	private String gender;
	@Column(length = 5,columnDefinition = "varchar2(255)")
	private String mobile;
	@Column(length = 5,columnDefinition = "varchar2(255)")
	private String email;
	@Column(length = 5,columnDefinition = "varchar2(255)")
	private String password;
	@Column(length = 5,columnDefinition = "varchar2(255)")
	private String c_pwd;
	@Column(length = 5,columnDefinition = "varchar2(255)")
	private String address;
	@Column(length = 5)
	private Double balance = 0.0;
	
	public Customer() 
	{
		super();
		
	}

	@Override
	public String toString() {
		return "Customer [c_id=" + c_id + ", fname=" + fname + ", lname=" + lname + ", dob=" + dob + ", gender="
				+ gender + ", mobile=" + mobile + ", email=" + email + ", password=" + password + ", c_pwd=" + c_pwd
				+ ", address=" + address + ", balance=" + balance + "]";
	}

	public Customer(int c_id, String fname, String lname, Date dob, String gender, String mobile, String email,
			String password, String c_pwd, String address, Double balance) {
		super();
		this.c_id = c_id;
		this.fname = fname;
		this.lname = lname;
		this.dob = dob;
		this.gender = gender;
		this.mobile = mobile;
		this.email = email;
		this.password = password;
		this.c_pwd = c_pwd;
		this.address = address;
		this.balance = balance;
	}
	

	
}




