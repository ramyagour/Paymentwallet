package com.capg.Ewallet.Service;

import java.util.List;

import com.capg.Ewallet.Beans.Customer;
import com.capg.Ewallet.Exception.RecordNotFoundException;

public interface IEwalletService 
{
public String login(String email,String pwd)throws RecordNotFoundException;
	
	public Customer registration(Customer customer)throws RecordNotFoundException;
	
	public Double checkBalance(int cid)throws RecordNotFoundException;
	
	public Double depositAmount(int cid,double amount)throws RecordNotFoundException;
	
	public Double withdrawAmount(int cid,double amount)throws RecordNotFoundException;
	
	public Double fundTransfer(int cid,int rid,double amount)throws RecordNotFoundException;
	
	public List<Customer> getAllCustomer()throws RecordNotFoundException;
	
	public Customer getSingleCustomerInfo(int cid)throws RecordNotFoundException;
	
	public Customer updateCustomer(Customer customer)throws RecordNotFoundException;
}
